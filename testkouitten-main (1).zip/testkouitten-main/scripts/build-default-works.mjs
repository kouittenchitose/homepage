/**
 * 内容メモ.md から作品一覧用の body（歌詞・語り等）を抽出して
 * functions/lib/default-works-full.js を生成する（開発時のみ実行）
 *
 *   node scripts/build-default-works.mjs [path/to/内容メモ.md]
 */
import { readFileSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const memoPath = process.argv[2] || join(process.env.HOME || '', 'Downloads/内容メモ.md');

const BASE = [
  {
    id: 'w2025',
    year: '2025',
    title: '一鳳（かげは）',
    story:
      '混沌の世界に鳳凰が誕生し、力を蓄え国を生み出し人々に安寧をもたらす。天命を全うしたあと、影に隠れていた邪知暴虐の王が圧政を敷き国は混乱に。民の祈りを受け鳳凰が再び姿を見せ、平和が戻る物語。',
    awards: [],
  },
  {
    id: 'w2024',
    year: '2024',
    title: '臨剋（りんこく）',
    story:
      'テーマ〜酒呑童子討伐〜。平和だった京で娘が攫われ、丹波国大江山の酒呑童子の仕業と判明。討伐隊は菩薩から神便鬼毒酒を授かり山伏となって忍び込み、人肉の宴にも動じぬことで心を許され、酔い潰れた酒呑童子を討ち京に平和を取り戻す。',
    awards: ['第33回YOSAKOIソーラン祭り U-40 優秀賞'],
  },
  {
    id: 'w2023',
    year: '2023',
    title: '紲伊（せつか）',
    story:
      'テーマ〜国産み〜。葦原中国でイザナギ・イザナミが天沼矛で淤能碁呂島を創り降臨。初めはイザナミからの求婚で島が不安定に消え、再びはイザナギからの求婚で島々が安定し、人や村が生まれ豊かに栄えていく神話。',
    awards: [],
  },
  {
    id: 'w2022',
    year: '2022',
    title: '啓天（ひぞら）',
    story:
      '「啓」はひらく、「天」は光一天や天を想起。コロナが収まり明るい未来へ向かう立春の陽の気を象徴し、春で始まり春で終わる希望の作品。読みはそれぞれ独立した漢字の組み合わせ。',
    awards: ['第25回みちのくYOSAKOIまつり ファイナル 第3位 仙台市長賞'],
  },
  {
    id: 'w2021',
    year: '2021',
    title: '光櫛（れいき）',
    story:
      'テーマは八雲の姫。2017年「灼耀」の後のスサノオから始まり、天の岩屋戸で高天原を追放され出雲の鳥髪山でヤマタノオロチの生贄となりかけたクシナダヒメと出会う。神通力で櫛に変えた姿で退治を行い、八雲の根之堅洲国・須賀の地で妻として迎え入れるまでを描く。',
    awards: [],
  },
  {
    id: 'w2020',
    year: '2020',
    title: '燦華（さんか）',
    story:
      '秋の大地の蕾が季節外れの薄桃色の花を咲かせ人々を魅了し、冬の吹雪に散るも蕾を残す。春には吹雪を越えた満開の桜が、心に眠る桜の記憶を呼び覚まし、宴の始まりへと導く生命の物語。',
    awards: [],
  },
  {
    id: 'w2019',
    year: '2019',
    title: '黎明（しののめ）',
    story:
      '暗闇からうっすらと陽の光が差し込み明るくなるにつれ雲が光を遮るが、光が奮い雲を押しのけ、やがて雲が消え去り日が昇る夜明けを迎える。',
    awards: ['第21回ちとせトーナメント セミトーナメント ベスト6'],
  },
  {
    id: 'w2018',
    year: '2018',
    title: '嵐奏（らんか）',
    story:
      '人が畏れるほどの偉大な力を見せる天然現象のうち、身近で代表的な強風と雷鳴を神格化した風神雷神をテーマに。古くから尊崇され、級長津彦命・級長津比売命や鳴雷神など各地の信仰に通じ、心の奏として命を灯す。',
    awards: ['第20回ちとせトーナメント ベスト16', '第21回みちのくYOSAKOIまつり ファイナル 第4位'],
  },
  {
    id: 'w2017',
    year: '2017',
    title: '灼耀（あすか）',
    story:
      'テーマは日本神話・天岩屋戸。スサノオの暴走でアマテラスが岩戸に籠り光を失った世界を、八百万神が施策し太陽を取り戻す。独立一年目の作品。「灼」はあきらかにかがやく、「耀」はかがやかす。飛鳥の明日香のように新たな日が昇るイメージ。',
    awards: [
      '第26回YOSAKOIソーラン祭り 敢闘賞',
      '第19回ちとせトーナメント ベスト8 レラ賞',
      '第20回みちのくYOSAKOIまつり ファイナル 第3位 仙台市長賞',
    ],
  },
  {
    id: 'w2016',
    year: '2016',
    title: '神瑞（かずい）',
    story:
      'カムイがもたらす瑞兆と花蕊のかずいを重ね、石狩川源流のイメージで山河を創る神々を描く。モシリ・カラ・カムイとイカ・カラ・カムイがレェプ・カムイ、コタン・コロ・カムイとともにアイヌモシリを創り、人は神から歌と踊りを教わり地上の生活を始める。2014「神煒」2015「嵩音」より前のエピソード。',
    awards: [
      '第25回YOSAKOIソーラン祭り セミファイナル進出',
      '第26回石狩川フェスティバル水祭 準グランプリ',
      '第19回みちのくYOSAKOIまつり ファイナル 第4位',
    ],
  },
  {
    id: 'w2015',
    year: '2015',
    title: '嵩音（かさね）',
    story:
      '「嵩」は崇高、「音」に鳴子やドラムを重ね「最も高い所に届く音」。コタンコロカムイの語りから、大鹿神との戦いで青年神から英雄神へ覚醒し、魔神との戦いで父・雷神の力を借り勝利。地上の平和とレタッチリ姫との結婚を祝福する物語。',
    awards: [
      '第24回YOSAKOIソーラン祭り セミファイナル 第3位',
      '第25回石狩川フェスティバル水祭 王座',
      '第17回ちとせトーナメント ベスト16',
      '第18回みちのくYOSAKOIまつり ファイナル進出 『第7位』',
    ],
  },
  {
    id: 'w2014',
    year: '2014',
    title: '神煒（しんき）',
    story:
      'チキサニカムイ伝説をオリジナルにアレンジ。コタンコロカムイが語る絶世の美女チキサニ姫と、創造神の弟である荒神カンナカムイ（雷神）。天上の掟を破り地上へ来た雷神が姫の上に落ち、炎の中から英雄アイヌラックルが誕生する誕生秘話。',
    awards: [
      '第23回YOSAKOIソーラン祭り セミファイナル 第3位',
      '第24回石狩川フェスティバル水祭 王座',
      '第16回ちとせトーナメント ベスト8',
      '第16回上川中央支部大会 準大賞',
    ],
  },
  {
    id: 'w2013',
    year: '2013',
    title: 'ラマッタ・クリムセ',
    story:
      'アイヌ語で「魂を呼ぶ踊り」。遨〜すさび〜＆光一天で唯一アイヌ語のタイトル。2014年からのアイヌ神話三部作のプロローグとなる予告的作品。',
    awards: ['第22回YOSAKOIソーラン祭り 一次審査員賞', '第15回ちとせトーナメント 優勝', '第15回上川中央支部大会 大賞'],
  },
  {
    id: 'w2012',
    year: '2012',
    title: '晶華（しょうか）',
    story:
      '結晶のように輝く華。セミファイナル進出を果たし、各地の大会で大賞を重ねた光一天の飛躍の年を象徴する作品。',
    awards: ['第21回YOSAKOIソーラン祭り セミファイナル 第4位', '第14回ちとせトーナメント 優勝', '第14回上川中央支部大会 大賞'],
  },
  {
    id: 'w2010',
    year: '2010',
    title: '光芒一閃（こうぼういっせん）',
    story:
      '当時は独自演舞作品がなく大学の学生チャレンジプログラムで企画された光一天初の単体作品。「光芒」はきらめく光の穂先、「一閃」は瞬時のきらめき。チームのアイデンティティ獲得を目指した記念碑的な一曲。',
    awards: ['第19回YOSAKOIソーラン祭り 一次審査員賞（依処）'],
  },
  {
    id: 'w2008',
    year: '2008',
    title: '紲（きずな）',
    story:
      '「遨〜すさび〜」としての本祭出場作。合同チームとの出会いの年。新人賞と敢闘賞を同時受賞し、その後の活動の原点となった作品。',
    awards: ['第17回YOSAKOIソーラン祭り 新人賞', '第17回YOSAKOIソーラン祭り 敢闘賞'],
  },
];

/** メモ内のマーカー行や画像ファイル名を除いてテキストを整形 */
function cleanRaw(text) {
  return text
    .split('\n')
    .filter((line) => {
      const t = line.trim();
      if (!t) return true;
      if (/\.(png|jpg|jpeg|gif|webp)$/i.test(t)) return false;
      if (t === 'image.png' || t.startsWith('スクリーンショット')) return false;
      return true;
    })
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** raw を start〜end（不含）で切り出し */
function sliceBetween(raw, start, end) {
  const i = raw.indexOf(start);
  if (i < 0) return '';
  const j = end ? raw.indexOf(end, i + start.length) : -1;
  if (j < 0) return raw.slice(i);
  return raw.slice(i, j);
}

/** セクション開始〜終端パターンまで（終端なしならチャンク末尾まで） */
function extractSection(raw, startPatterns, endPatterns) {
  if (!raw) return '';
  let start = -1;
  for (const p of startPatterns) {
    const i = raw.indexOf(p);
    if (i >= 0 && (start < 0 || i < start)) start = i;
  }
  if (start < 0) return '';
  let rest = raw.slice(start);
  if (!endPatterns || endPatterns.length === 0) return cleanRaw(rest);
  let cut = rest.length;
  for (const ep of endPatterns) {
    const j = rest.indexOf(ep, 10);
    if (j >= 0 && j < cut) cut = j;
  }
  return cleanRaw(rest.slice(0, cut));
}

let memoRaw = '';
try {
  memoRaw = readFileSync(memoPath, 'utf8');
} catch (e) {
  console.warn('メモファイルが読めません:', memoPath, '- body はプレースホルダのみ生成します');
}

const bodies = {};

if (memoRaw) {
  const c2025 = sliceBetween(memoRaw, '一鳳＜かげは＞', '臨剋＜りんこく＞');
  bodies.w2025 = extractSection(c2025, ['<歌詞>', '☆成長☆'], []);

  const c2024 = sliceBetween(memoRaw, '臨剋＜りんこく＞', '紲伊＜せつか＞');
  bodies.w2024 = extractSection(c2024, ['<歌詞>', 'OP\n栄華'], []);

  const c2023 = sliceBetween(memoRaw, '紲伊＜せつか＞', '作品名');
  bodies.w2023 = extractSection(c2023, ['テーマ～国産み～', '<歌詞>', '綻びし'], []);

  const c2022 = sliceBetween(memoRaw, '『啓天-ひぞら-』', '光櫛〈れいき〉');
  bodies.w2022 = extractSection(c2022, ['読み方はそれぞれ', 'OP\n花ほころぶ', '花ほころぶ'], []);

  const c2021 = sliceBetween(memoRaw, '光櫛〈れいき〉', '燦華〈さんか〉');
  bodies.w2021 = extractSection(c2021, ['【OP】', 'テーマ*八雲の姫', '歌詞'], []);

  const c2020 = sliceBetween(memoRaw, '燦華〈さんか〉', '黎明<しののめ>');
  bodies.w2020 = extractSection(c2020, ['【蕾】', '物静かな秋'], []);

  const c2019 = sliceBetween(memoRaw, '黎明<しののめ>', '嵐奏＜らんか＞');
  bodies.w2019 = extractSection(c2019, ['歌詞', '今宵空に'], []);

  const c2018 = sliceBetween(memoRaw, '嵐奏＜らんか＞', '灼耀<あすか>');
  bodies.w2018 = extractSection(c2018, ['人間が怖れ', '​歌詞', '鰊来たかと'], []);

  const c2017 = sliceBetween(memoRaw, '灼耀<あすか>', '神瑞<かずい>');
  bodies.w2017 = extractSection(c2017, ['テーマ：日本神話', 'ストーリー', '​歌詞', '悲しみの果てに'], []);

  const c2016 = sliceBetween(memoRaw, '神瑞<かずい>', '嵩音＜かさね＞');
  bodies.w2016 = extractSection(c2016, ['カムイのもたらした', '​歌詞', '滝の飛沫も'], []);

  const c2015 = sliceBetween(memoRaw, '嵩音＜かさね＞', '神偉<sinki>');
  bodies.w2015 = extractSection(c2015, ['語源は「重ね合わせる」', 'ストーリー', '​歌詞', 'ヤーレンソーラン'], []);

  const c2014 = sliceBetween(memoRaw, '神偉<sinki>', 'ラマッタ・クリムセ');
  bodies.w2014 = extractSection(c2014, ['アイヌ民族に伝わる', '​歌詞', '嗚呼'], []);

  const c2013 = sliceBetween(memoRaw, 'ラマッタ・クリムセ', '\n2012\n');
  if (!c2013) {
    bodies.w2013 = extractSection(sliceBetween(memoRaw, 'ラマッタ・クリムセ', '2012'), ['遨～すさび～＆光一天で唯一', '​歌詞', '幾千の夜'], []);
  } else {
    bodies.w2013 = extractSection(c2013, ['遨～すさび～＆光一天で唯一', '​歌詞', '幾千の夜'], []);
  }

  bodies.w2012 =
    'メモではタイトルのみの記載です。詳細な歌詞・語りは別資料があり次第、管理画面の「詳細解説」に追記できます。';

  const c2010 = sliceBetween(memoRaw, '光芒一閃', '２０１０年');
  bodies.w2010 = extractSection(memoRaw, ['制作ストーリー', '​テーマ', '千歳翔け行く'], ['\n\n\n\n２０１０年']);
  if (!bodies.w2010 || bodies.w2010.length < 20) {
    bodies.w2010 = extractSection(sliceBetween(memoRaw, '光芒一閃\n<こうぼういっせん>', '２０１０年'), ['​歌詞', '千歳翔け行く'], []);
  }

  bodies.w2008 =
    'メモでは2008年「紲」は見出しのみです。夕張・「桜の刻」・WARM時代の記述はメモ後半の「幻の作品」「光一天とは」付近を参照してください。';
}

function fmtBody(id) {
  let extra = bodies[id] || '';
  extra = cleanRaw(extra);
  if (!extra) {
    return (
      '【詳細解説】\n\n内容メモからの自動抽出に失敗しました。`node scripts/build-default-works.mjs /path/to/内容メモ.md` を実行するか、管理画面で「詳細解説」に入力してください。'
    );
  }
  return extra;
}

const outWorks = BASE.map((w) => ({
  ...w,
  image: '',
  body: fmtBody(w.id),
}));

const outPath = join(__dirname, '../functions/lib/default-works-full.js');
writeFileSync(
  outPath,
  `// 自動生成: node scripts/build-default-works.mjs\n// メモを更新したら再実行してください。\nexport const defaultWorks = ${JSON.stringify(outWorks, null, 2)};\n`,
  'utf8'
);
console.log('Wrote', outPath, 'works:', outWorks.length);
